# -*- coding: utf-8 -*-

from classification import Classification
from sklearn.linear_model import LogisticRegression
from baseline import Baseline
from dialogue_agent import Dialogue_Agent
from sklearn.neural_network import MLPClassifier
from sklearn.decomposition import TruncatedSVD
da = Dialogue_Agent()


